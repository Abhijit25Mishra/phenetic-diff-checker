import azure.cognitiveservices.speech as speechsdk
import json
import logging
import os
import sys
import datetime
from dotenv import load_dotenv

# --- CONFIGURATION ---
load_dotenv()
SPEECH_KEY = os.getenv("SPEECH_KEY")
SPEECH_REGION = os.getenv("SPEECH_REGION")

# Basic logging for script errors
logging.basicConfig(
    filename="pronunciation_script.log",
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s'
)

def process_pronunciation_result(json_payload, reference_text, threshold=80):
    """
    Parses Azure JSON result and generates a UI-ready format highlighting errors.
    """
    # 1. Safety Check: Azure sometimes returns empty NBest lists
    nbest = json_payload.get('NBest', [])
    if not nbest:
        return {"error": "No recognition result found"}

    best_attempt = nbest[0]
    words_data = best_attempt.get('Words', [])

    highlighted_words = []

    # 2. Iterate through Azure's word analysis
    for word_info in words_data:
        word_text = word_info.get('Word')
        error_type = word_info.get('PronunciationAssessment', {}).get('ErrorType', 'None')

        # --- CHECK 1: OMISSION / INSERTION ---
        if error_type == "Omission":
            # The user skipped this word completely -> RED
            highlighted_words.append({"word": word_text, "color": "red"})
            continue

        elif error_type == "Insertion":
            # The user said an extra word -> RED
            highlighted_words.append({"word": word_text, "color": "red"})
            continue

        # --- CHECK 2: PHONEME ACCURACY ---
        phonemes = word_info.get('Phonemes', [])

        if not phonemes:
            # Fallback: If no phonemes, rely on word-level score
            word_score = word_info.get('PronunciationAssessment', {}).get('AccuracyScore', 0)
            color = "green" if word_score >= threshold else "red"
            highlighted_words.append({"word": word_text, "color": color})
            continue

        # Count how many phonemes failed the threshold
        bad_phoneme_count = 0
        total_phonemes = len(phonemes)

        for ph in phonemes:
            ph_score = ph.get('PronunciationAssessment', {}).get('AccuracyScore', 0)
            if ph_score < threshold:
                bad_phoneme_count += 1

        # Calculate percentage of bad phonemes
        failure_rate = (bad_phoneme_count / total_phonemes) * 100

        # Rule: If > 20% of phones are bad, mark word as RED
        if failure_rate > 20:
            color = "red"
        else:
            color = "green"

        highlighted_words.append({"word": word_text, "color": color})

    return {
        "returned_sentence": reference_text,
        "highlights": highlighted_words
    }

def check_pronunciation_azure(audio_file, reference_text):
    if not SPEECH_KEY or not SPEECH_REGION:
        logging.error("Missing Azure Credentials in .env")
        # Write error to output for UI to see
        with open("output.json", "w", encoding='utf-8') as f:
            json.dump({"error": "Configuration Error: Missing Azure Credentials"}, f)
        return

    if not os.path.exists(audio_file):
        logging.error(f"Audio file not found: {audio_file}")
        with open("output.json", "w", encoding='utf-8') as f:
            json.dump({"error": "Audio file not found"}, f)
        return

    try:
        speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, region=SPEECH_REGION)
        speech_config.speech_recognition_language = "en-IN"
        
        audio_config = speechsdk.audio.AudioConfig(filename=audio_file)

        # Phoneme level settings
        pronunciation_config = speechsdk.PronunciationAssessmentConfig(
            reference_text=reference_text,
            grading_system=speechsdk.PronunciationAssessmentGradingSystem.HundredMark,
            granularity=speechsdk.PronunciationAssessmentGranularity.Phoneme,
            enable_miscue=True
        )

        recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)
        pronunciation_config.apply_to(recognizer)

        result = recognizer.recognize_once()

        if result.reason == speechsdk.ResultReason.RecognizedSpeech:
            json_payload = result.properties.get(speechsdk.PropertyId.SpeechServiceResponse_JsonResult)
            
            # --- REQUIREMENT: Log Raw JSON to file (Append Mode) ---
            try:
                with open("raw_azure_log.json", "a", encoding='utf-8') as log_f:
                    log_f.write(json.dumps({"timestamp": str(datetime.datetime.now()), "payload": json.loads(json_payload)}) + "\n")
            except Exception as e:
                logging.error(f"Failed to log raw JSON: {e}")

            # --- REQUIREMENT: Process for UI ---
            data = json.loads(json_payload)
            processed_output = process_pronunciation_result(data, reference_text)

            # --- REQUIREMENT: Return response back to UI via output.json ---
            with open("output.json", "w", encoding='utf-8') as f:
                json.dump(processed_output, f, indent=2)
                
        elif result.reason == speechsdk.ResultReason.NoMatch:
            logging.warning("No speech recognized")
            with open("output.json", "w", encoding='utf-8') as f:
                json.dump({"error": "No speech could be recognized. Please try again."}, f)
                
        elif result.reason == speechsdk.ResultReason.Canceled:
            cancellation_details = result.cancellation_details
            logging.error(f"Speech canceled: {cancellation_details.reason} - {cancellation_details.error_details}")
            with open("output.json", "w", encoding='utf-8') as f:
                json.dump({"error": f"Speech recognition failed: {cancellation_details.reason}"}, f)
                
    except Exception as e:
        logging.critical(f"Critical error: {e}")
        with open("output.json", "w", encoding='utf-8') as f:
            json.dump({"error": f"Server processing error: {str(e)}"}, f)

if __name__ == "__main__":
    # Use the file generated by the backend
    AUDIO_FILE = "temp/test_audio.wav"
    
    # Get text from command line argument, w/ fallback
    TEXT_INPUT = sys.argv[1] if len(sys.argv) > 1 else "please put the pan on the table"
    
    check_pronunciation_azure(AUDIO_FILE, TEXT_INPUT)