"use client";

import { useState, useEffect } from "react";
import { AudioRecorder } from "@/components/AudioRecorder";
import { ArrowRight, CheckCircle, AlertCircle, Loader2, Trash2, History, Sparkles, X } from "lucide-react";
import clsx from "clsx";

interface Highlight {
  word: string;
  color: string;
}

interface AssessmentResult {
  id: string;
  error?: string;
  returned_sentence?: string;
  highlights?: Highlight[];
  timestamp: number;
}

const STORAGE_KEY = "pronunciation-history";

// Helper to load history from localStorage
const loadHistory = (): AssessmentResult[] => {
  if (typeof window === "undefined") return [];
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

// Helper to save history to localStorage
const saveHistory = (history: AssessmentResult[]) => {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
};

// Generate unique ID
const generateId = () => `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

export default function Home() {
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [textInput, setTextInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<AssessmentResult[]>([]);
  const [mounted, setMounted] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [useMockProcessor, setUseMockProcessor] = useState(true); // Default to mock processor

  // Load history from localStorage on mount
  useEffect(() => {
    setMounted(true);
    setHistory(loadHistory());
  }, []);

  // Save history whenever it changes
  useEffect(() => {
    if (mounted) {
      saveHistory(history);
    }
  }, [history, mounted]);

  const handleAudioRecorded = (blob: Blob) => {
    setAudioBlob(blob);
    setError(null);
  };

  const isSubmitEnabled = !!audioBlob && textInput.trim().length > 0 && !isLoading;

  const handleSubmit = async () => {
    if (!audioBlob || !textInput.trim()) return;

    setIsLoading(true);
    setError(null);

    const formData = new FormData();
    formData.append("audio", audioBlob, "recording.wav");
    formData.append("text", textInput);
    formData.append("processorType", useMockProcessor ? "mock" : "comparison");

    try {
      const response = await fetch("/api/process", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to process request");
      }

      const data = await response.json();

      // Add to history with unique id and timestamp
      const newEntry: AssessmentResult = {
        ...data,
        id: generateId(),
        timestamp: Date.now(),
      };

      setHistory(prev => [newEntry, ...prev]);
      setTextInput("");
      setAudioBlob(null);
    } catch (err: unknown) {
      console.error(err);
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = (id: string) => {
    setDeletingId(id);
    // Small delay for animation
    setTimeout(() => {
      setHistory(prev => prev.filter(item => item.id !== id));
      setDeletingId(null);
    }, 200);
  };

  const renderHighlightedText = (highlights: Highlight[] | undefined) => {
    if (!highlights || highlights.length === 0) {
      return <span className="text-zinc-400 italic">No feedback available</span>;
    }

    return (
      <span className="leading-loose text-xl">
        {highlights.map((item, index) => {
          const isError = item.color?.toLowerCase() === "red";
          return (
            <span key={index}>
              <span
                className={clsx(
                  "transition-all duration-300",
                  isError
                    ? "text-red-500 font-bold relative error-word"
                    : "text-slate-200"
                )}
              >
                {item.word}
              </span>
              {index < highlights.length - 1 && "   "}
            </span>
          );
        })}
      </span>
    );
  };

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 relative overflow-hidden ">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl animate-float-delayed" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-500/5 rounded-full blur-3xl" />
      </div>

      {/* Grid Pattern Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px] pointer-events-none" />

      {/* Mode Toggle Button */}
      <div className="absolute top-6 right-6 z-50">
        <button
          onClick={() => setUseMockProcessor(!useMockProcessor)}
          className={clsx(
            "flex items-center gap-2 px-4 py-2 rounded-full border text-sm font-medium transition-all backdrop-blur-md shadow-lg",
            useMockProcessor
              ? "bg-cyan-500/10 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/20"
              : "bg-purple-500/10 border-purple-500/30 text-purple-400 hover:bg-purple-500/20"
          )}
        >
          <div className={clsx("w-2 h-2 rounded-full", useMockProcessor ? "bg-cyan-400" : "bg-purple-400")} />
          {useMockProcessor ? "Mock Processor" : "Real Processor"}
        </button>
      </div>

      <div className="relative z-10 p-10 md:p-10 lg:p-12 max-w-2xl mx-auto flex flex-col gap-10" style={{ gap: "10px" }}>
        {/* Header */}
        <header className="text-center space-y-6 pt-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-cyan-400 text-sm font-medium backdrop-blur-sm">
            <Sparkles className="w-4 h-4" />
            AI-Powered Analysis
          </div>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-black tracking-tight">
            <span className="text-white">Pronunciation</span>
            <br />
            <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Checker
            </span>
          </h1>
          <p className="text-slate-400 text-lg md:text-xl max-w-lg mx-auto leading-relaxed">
            Record your voice and get instant feedback on your pronunciation accuracy
          </p>
        </header>

        {/* Input Card */}
        <div className="glass-card rounded-3xl p-10 mx-auto w-3/4 ">
          <div className="flex flex-col items-center gap-8 w-2/5 mx-auto" style={{ gap: "10px" }}>
            {/* Audio Recorder */}
            <div className="flex flex-col items-center gap-3">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full blur-xl opacity-30 scale-110" />
                <div className="relative p-2 rounded-full bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-white/10">
                  <AudioRecorder onAudioRecorded={handleAudioRecorded} />
                </div>
              </div>
              {audioBlob ? (
                <div className="text-emerald-400 flex items-center gap-2 text-sm font-medium animate-fade-in">
                  <CheckCircle className="w-4 h-4" />
                  Audio captured
                </div>
              ) : (
                <span className="text-slate-500 text-sm">Click to record</span>
              )}
            </div>

            {/* Divider */}
            <div className="h-px w-3/4 bg-gradient-to-r from-transparent via-white/20 to-transparent" />

            {/* Text Input */}
            <div className="relative group w-full max-w-sm mx-auto flex items-center gap-3">
              <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-xl blur opacity-0 group-focus-within:opacity-100 transition-opacity duration-300" />
              <input
                type="text"
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                placeholder="Enter the text you're reading..."
                className="relative w-full px-4 py-3 rounded-xl bg-white border border-slate-200 text-black placeholder:text-slate-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all text-base"
              />
            </div>

            {/* Submit Button */}
            <button
              onClick={handleSubmit}
              disabled={!isSubmitEnabled}
              className={clsx(
                "w-full py-3 rounded-xl font-semibold text-base flex items-center justify-center gap-2 transition-all transform active:scale-[0.98]",
                isSubmitEnabled
                  ? "bg-gradient-to-r from-cyan-500 to-purple-500 text-white shadow-lg shadow-purple-500/25 hover:shadow-xl hover:shadow-purple-500/30 hover:brightness-110"
                  : "bg-white/5 text-slate-600 border border-white/10 cursor-not-allowed"
              )}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  Analyze Pronunciation
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            {error && (
              <div className="w-full p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center gap-3 animate-fade-in text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                {error}
              </div>
            )}
          </div>
        </div>

        {/* History Section */}
        <section className="glass-card rounded-3xl overflow-hidden w-[60vw] mx-auto">
          {/* Header */}
          <div className="px-8 py-7 border-b border-white/10 flex flex-col items-center justify-center text-center">
            <div className="flex items-center gap-4 mb-2">
              <div className="p-3 rounded-xl bg-gradient-to-br from-cyan-500/20 to-purple-500/20 border border-white/10">
                <History className="w-5 h-5 text-cyan-400" />
              </div>
              <h2 className="text-xl font-bold text-white">Assessment History</h2>
            </div>
            {history.length > 0 && (
              <span className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-slate-400 text-sm font-medium">
                {history.length} {history.length === 1 ? 'entry' : 'entries'}
              </span>
            )}
          </div>

          {/* Content */}
          <div className="p-6 md:p-8">
            {!mounted ? (
              <div className="flex items-center justify-center py-20 text-slate-500">
                <Loader2 className="w-8 h-8 animate-spin" />
              </div>
            ) : history.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-slate-500 text-center">
                <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-4">
                  <History className="w-8 h-8 text-slate-600" />
                </div>
                <p className="text-lg font-medium text-slate-400">No assessments yet</p>
              </div>
            ) : (
              <div className="space-y-5">
                {history.map((item, index) => (
                  <div
                    key={item.id}
                    className={clsx(
                      "group relative overflow-hidden rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 hover:bg-white/[0.07] transition-all duration-300",
                      deletingId === item.id && "opacity-0 scale-95 -translate-x-4",
                      "animate-fade-in"
                    )}
                    style={{ animationDelay: `${index * 60}ms` }}
                  >
                    {/* Hover Gradient */}
                    <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                    <div className="relative p-6 md:p-7">
                      {/* Delete Button */}
                      <button
                        onClick={() => handleDelete(item.id)}
                        className="absolute top-5 right-5 p-2.5 rounded-xl text-slate-500 hover:text-red-400 hover:bg-red-500/10 border border-transparent hover:border-red-500/20 opacity-0 group-hover:opacity-100 transition-all duration-200"
                        title="Remove from history"
                      >
                        <X className="w-4 h-4" />
                      </button>

                      {/* Content */}
                      {item.error ? (
                        <div className="text-red-400 flex items-center justify-center gap-3">
                          <AlertCircle className="w-5 h-5" />
                          Error: {item.error}
                        </div>
                      ) : (
                        <div className="space-y-4 text-center">
                          <div className="min-h-[2rem]">
                            {renderHighlightedText(item.highlights)}
                          </div>
                          <div className="flex items-center justify-center gap-3">
                            <span className="text-xs text-slate-500 font-medium">
                              {formatTime(item.timestamp)}
                            </span>
                            {item.highlights && (
                              <span className="text-xs text-slate-600">
                                •
                              </span>
                            )}
                            {item.highlights && (
                              <span className="text-xs text-slate-500">
                                {item.highlights.filter(h => h.color?.toLowerCase() === 'red').length} errors
                              </span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

      </div>
    </main>
  );
}
