import { NextRequest, NextResponse } from "next/server";
import { writeFile, readFile, mkdir } from "fs/promises";
import { exec } from "child_process";
import { promisify } from "util";
import path from "path";
import fs from "fs";

const execAsync = promisify(exec);

export async function POST(request: NextRequest) {
    try {
        const formData = await request.formData();
        const audioFile = formData.get("audio") as File;
        const text = formData.get("text") as string;
        const processorType = formData.get("processorType") as string;

        if (!audioFile || !text) {
            return NextResponse.json(
                { error: "Missing audio or text" },
                { status: 400 }
            );
        }

        // Ensure temp directory exists
        const tempDir = path.join(process.cwd(), "temp");
        if (!fs.existsSync(tempDir)) {
            await mkdir(tempDir);
        }

        // Save uploaded audio file
        const buffer = Buffer.from(await audioFile.arrayBuffer());
        const inputFilePath = path.join(tempDir, "input_audio"); // No extension initially, or use generic
        await writeFile(inputFilePath, buffer);

        // Step 1: Run FFmpeg
        // We convert input to 16kHz mono wav
        const outputWavPath = path.join(tempDir, "test_audio.wav");
        const ffmpegCommand = `ffmpeg -y -i "${inputFilePath}" -ac 1 -ar 16000 "${outputWavPath}"`;

        console.log("Running FFmpeg:", ffmpegCommand);
        await execAsync(ffmpegCommand);

        // Step 2: Run Python Script
        // Determine which script to run based on processorType
        const scriptName = processorType === "comparison" ? "comparison_processor.py" : "mock_processor.py";

        // The script is in the root directory
        const pythonScriptPath = path.join(process.cwd(), scriptName);
        // Use the specific virtual environment python
        const venvPythonPath = path.join(process.cwd(), "..", ".venv", "bin", "python");

        // Escape quotes in text to prevent shell injection/breaking
        const safeText = text.replace(/"/g, '\\"');
        const pythonCommand = `"${venvPythonPath}" "${pythonScriptPath}" "${safeText}"`;

        console.log("Running Python:", pythonCommand);
        const { stdout, stderr } = await execAsync(pythonCommand);
        console.log("Python stdout:", stdout);
        if (stderr) console.error("Python stderr:", stderr);

        // Step 3: Read Output Log
        const outputJsonPath = path.join(process.cwd(), "output.json");
        if (!fs.existsSync(outputJsonPath)) {
            throw new Error("Output JSON file was not created by the script");
        }

        const outputContent = await readFile(outputJsonPath, "utf-8");
        const jsonResponse = JSON.parse(outputContent);

        return NextResponse.json(jsonResponse);

    } catch (error: any) {
        console.error("Processing error details:", error);
        // Return detailed error message for debugging
        return NextResponse.json(
            { error: error.message || "Internal Server Error", details: error.toString() },
            { status: 500 }
        );
    }
}
