"use client";

import { useState, useRef } from "react";
import { Mic, Square } from "lucide-react";
import clsx from "clsx";

interface AudioRecorderProps {
    onAudioRecorded: (audioBlob: Blob) => void;
    onRecordingStart?: () => void;
}

export function AudioRecorder({ onAudioRecorded, onRecordingStart }: AudioRecorderProps) {
    const [isRecording, setIsRecording] = useState(false);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const chunksRef = useRef<Blob[]>([]);

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const mediaRecorder = new MediaRecorder(stream);
            mediaRecorderRef.current = mediaRecorder;
            chunksRef.current = [];

            mediaRecorder.ondataavailable = (e) => {
                if (e.data.size > 0) {
                    chunksRef.current.push(e.data);
                }
            };

            mediaRecorder.onstop = () => {
                const audioBlob = new Blob(chunksRef.current, { type: "audio/wav" });
                onAudioRecorded(audioBlob);

                // Stop all tracks
                stream.getTracks().forEach((track) => track.stop());
            };

            mediaRecorder.start();
            setIsRecording(true);
            if (onRecordingStart) onRecordingStart();
        } catch (err) {
            console.error("Error accessing microphone:", err);
            alert("Could not access microphone. Please ensure specific permissions are granted.");
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
        }
    };

    const handleClick = () => {
        if (isRecording) {
            stopRecording();
        } else {
            startRecording();
        }
    };

    return (
        <div className="flex flex-col items-center justify-center">
            <button
                onClick={handleClick}
                className={clsx(
                    "relative p-5 rounded-full transition-all duration-300 flex items-center justify-center group",
                    isRecording
                        ? "bg-red-500/20 border-2 border-red-500/50"
                        : "bg-white/10 border-2 border-white/20 hover:border-cyan-500/50 hover:bg-cyan-500/10"
                )}
                aria-label={isRecording ? "Stop Recording" : "Start Recording"}
                title={isRecording ? "Stop Recording" : "Record Audio"}
            >
                {/* Animated ring when recording */}
                {isRecording && (
                    <>
                        <span className="absolute inset-0 rounded-full bg-red-500/20 animate-ping" />
                        <span className="absolute inset-[-4px] rounded-full border-2 border-red-500/30 animate-pulse" />
                    </>
                )}
                
                {isRecording ? (
                    <Square className="w-6 h-6 text-red-400 fill-red-400 relative z-10" />
                ) : (
                    <Mic className="w-6 h-6 text-slate-400 group-hover:text-cyan-400 transition-colors relative z-10" />
                )}
            </button>
        </div>
    );
}
